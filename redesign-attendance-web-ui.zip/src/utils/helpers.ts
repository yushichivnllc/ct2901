// Helper types and utilities
export interface AttendanceRecord {
  id: string;
  name: string;
  timestamp: number;
  status: "present" | "absent-excused" | "absent-unexcused";
}

export interface Session {
  id: string;
  name: string;
  createdAt: number;
  savedAt?: number;
  records: AttendanceRecord[];
}

export function formatTime(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function formatDate(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleDateString("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

export function formatDateTime(timestamp: number): string {
  return `${formatDate(timestamp)} ${formatTime(timestamp)}`;
}

export const COLORS = {
  teal: "#3ECAD6",
  amber: "#F0A94A",
  violet: "#7B6CFF",
  rose: "#FF6B8A",
  ink: "#1C1C1C",
};

// Generate a random ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

// Get avatar color based on name
export function getAvatarColor(name: string): string {
  const colors = ["#3ECAD6", "#F0A94A", "#7B6CFF", "#FF6B8A", "#22B8C6", "#E89628", "#5B8DEF", "#34D399"];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

// Get initials from name
export function getInitials(name: string): string {
  const parts = name.split(" ").filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}
